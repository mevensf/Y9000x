﻿



编译步骤：

sudo mysql -uroot -p

source mysql.sql;

quit;

make clean

make
./server
./client

