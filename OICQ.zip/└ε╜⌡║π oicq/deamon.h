#ifndef _DEAMON_H_
#define _DEAMON_H_

#include<stdio.h>
#include<stdlib.h>
#include<unistd.h>
#include<signal.h>
#include<sys/types.h>
#include<sys/param.h>
#include<sys/stat.h>


void init_deamon();

#endif
