#include<stdio.h>
#include<string.h>
#include <stdlib.h>
#include"student.h"
#include"teacher.h"
#include "tooler.h"
#include "main.h"
/*
struct member 
{
	char name[32];
}m1={"admin"},m2={"teacher"},m3={"student"};

int count=0;
extern int count;
*/



int count = 0;
struct member  m1={"admin"},m2={"teacher"},m3={"student"};

void  main()
{
		int num;

		printf("      ***** 欢迎您进入学生管理系统 *****\n");
		printf("--------------------------------------------\n");
		printf("-----            1.admin               -----\n");
		printf("-----            2.teacher             -----\n");
		printf("-----            3.student             -----\n");
		printf("--------------------------------------------\n");
                printf("\n");
		printf("请输入您的选择(1~3):\n");
		scanf("%d",&num);
		
		if(num==1)
		{
			printf("\t*****欢迎%s访问校管理系统*****\n",m1.name);
			printf("     请输入您的帐号与密码完成登录...\n");
			passwd_admin();
		
		}
  
		else if(num==2)
		{
			printf("\t*****欢迎%s访问校管理系统*****\n",m2.name);
			printf("     请输入您的帐号与密码完成登录...\n");
                        passwd_teacher();
			
		}
		else if(num==3)
		{
			printf("\t*****欢迎%s访问校管理系统*****\n",m3.name);
			printf("     请输入您的帐号与密码完成登录...\n");
                        passwd_student();
		}
		else
		{
				printf("date error!\n");
				printf("请重新确认您的选择！！！\n");
				main();
		}


}

