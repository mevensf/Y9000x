
#ifndef _MAIN_H
#define _MAIN_H

#include<stdio.h>
struct member 
{
	char name[32];
};

extern struct  member m1;
extern struct  member m2;
extern struct  member m3;
extern int count;


#endif
