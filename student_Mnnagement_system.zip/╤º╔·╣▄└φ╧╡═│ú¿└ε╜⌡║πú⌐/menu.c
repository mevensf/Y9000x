        //主菜单
        void student_menu()
        {
                int n=0;

                system("CLS");
                printf(" 学生信息管理系统\ni");
                printf("\n");
                printf("-------------------MENU-----------------\n");
                printf(" 1.登记学生信息\n");
                printf(" 2.删除学生信息\n");
                printf(" 3.修改学生信息\n");
                printf(" 4.显示已经登记的学生\n");
                printf(" 5.查找\n");
                printf(" 5.1按学号查找\n");
                printf(" 5.2按姓名查找\n");
                printf(" 5.3按班级查找\n");
                printf(" 6依据总成绩排序\n");
                printf(" 7.存储到文件\n");
                printf(" 8.从文件导出\n");
                printf(" 9.退出系统\n");
                printf(" 请选择：");
                scanf("%d",&n);
                switch (n) 
                {
                        case 1:
                                add_student();
                                break;
                        case 2:
                                del();
                                break;
                        case 3:
                                revise();
                                break;
                        case 4:
                            displaystudentbasic();
                                break;
                        case 5:

                                search();
                                break;
                        case 6:
                                sort();
                                break;
                        case 7:
                                save();
                                break;
                        case 8:
                                read();
                                break;
                        case 9:
                                exit(0);
                                break;
                        default:
                                {
                                                            

//主菜单
void teacher_menu()
{
        int n;

        system("CLS");
        printf(" ***********高校老师信息管理系统***********\n");
        printf("\n");
        printf("-------------------MENU-----------------\n");
        printf(" 1.添加信息\n");
        printf(" 1.1添加学生信息\n");
        printf(" 1.2添加老师信息\n");
        printf(" 2.删除学生\n");
        printf(" 2.1删除学生信息\n");
        printf(" 2.2删除老师信息\n");
        printf(" 3.修改信息\n");
        printf(" 3.2修改学生信息\n");
        printf(" 3.1修改老师信息\n");
        printf(" 4.显示基本信息\n");
        printf(" 4.1显示学生基本信息\n");
        printf(" 4.2显示老师基本信息\n");
        printf(" 5.查找信息\n");
        printf(" 5.1按学号查找学生\n");
        printf(" 5.2按姓名查找学生\n");
        printf(" 5.3按编号查找老师\n");
        printf(" 5.4按姓名查找老师\n");
        printf(" 6.退出系统\n");
        printf(" 请选择：");
        scanf("%d",&n);
        switch (n) 
        {
                case 1:
                        add();
                        break;
                case 2:
                        del();
                        break;
                case 3:
                        revise();
                        break;
                case 4:
                        display();
                        break;
                case 5:
                        search();
                        break;
    
                case 6:
                        exit(0);
                        break;
    
               default:
                       {
                               printf("请输入1~6之间的数字，谢谢！\n");
                               break
                       }

         teacher_menu;
}


                       
