#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include"tooler.h"
#include"student.h"
#include"teacher.h"
#include "main.h"

#define S  100



STUDENT student[S];
void student_menu();

//提示
void stu_sign()
{
		char s[20];
		printf("\n");
		printf("还需要操作么？如果需要操作请输入：yes，否则请输入：no\n");
		scanf("%s",s);
		if(strcmp(s,"yes")==0)
		{
			student_menu();
		}
		else if(strcmp(s,"no")==0)
				exit(0);
		else
		{
				printf("请输入正确的字符，谢谢！\n");
				stu_sign();
		}
}

//密码输入

void passwd_student()
{
        char id[32]="MDA14130",passwd[32]="12345678";
        int i,n=3;
        printf("***********欢迎登录高校信息管理系统!**********\n");
		while(1)
		{

        printf("请输入登录帐号与密码：");
        scanf("%s%s",id,passwd);
        if(strcmp(id,"MDA14130")==0&&strcmp(passwd,"12345678")==0)
        {
                printf("\t\t\t\t帐号密码正确！欢迎登录！");
                printf("******      欢迎进入主菜单      ******");
                student_menu();

        }
        else
         {
                
                printf("对不起!帐号或者密码错误，请确认后再次登录！");
                printf("您还剩%d次登录机会！",n);
                n--;
                if(n==0)
                {
                        printf("您已超过当日登录次数，请隔日再试!");
		        break;
                }

        }
		}
      stu_sign();


}

                                                      

//添加基本信息（学生姓名，年龄，成绩）
void add_student()
{
		int rs;
		int i;

//		system("CLS");
		printf("请输入需要输入几个学生信息：");
		scanf("%d",&rs);
		for(i=count;i<count+rs;i++)
		{
				printf("请输入第%d个学生的学号：",i+1);
				scanf("%d",&student[i].number);
				printf("请输入学生的姓名：");
				scanf("%s",student[i].name);
				printf("请输入学生的年龄：");
				scanf("%d",&student[i].age);
				printf("请输入学生的性别：");
				scanf("%s",student[i].sex);
				printf("请输入高数课的成绩：");
				scanf("%d",&student[i].gaoshu);
				printf("请输入英语的成绩：");
				scanf("%d",&student[i].yingyu);
				printf("请输入计算机的成绩：");
				scanf("%d",&student[i].jisuanji);
				student[i].sum=student[i].gaoshu+student[i].yingyu+student[i].jisuanji;
				printf("第%d个同学总成绩：%d\n",i+1,student[i].sum);
				student[i].average=student[i].sum/3.0;
				printf("第%d个同学平均成绩：%lf\n",i+1,student[i].average);
		}

		count=count+rs;
		count++;
		tea_sign();
		//stu_sign();

	
}

//学生信息
void displaystudentbasic()
{
        int i;
        system("clear");
        if(count==0)
        {
                printf("not input before\n");
                getchar();
                return;
        }
        printf("学生信息如下所示：\n");
        printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
        printf("学号：\t姓名：\t高数：\t英语：\t计算机:\t总分:\t序号\n");
                for(i=0;i<count;i++)
                {
                        printf("%d\t",student[i].number);
                        printf("%s\t",student[i].name);
                        printf("%d\t",student[i].gaoshu);
                        printf("%d\t",student[i].yingyu);
                        printf("%d\t",student[i].jisuanji);
                        student[i].sum=student[i].gaoshu+student[i].yingyu+student[i].jisuanji;
                        printf("%d\t",student[i].sum);
                        printf("%d\n",i);
                }
                
        printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
             // printf("点击任意建继续！");
             // getchar();
	      admin_sign();


//        student_menu();
}

//删除学生信息(teacher)
void del_student()
{
		char delinfo[32];

		system("CLS");
		printf("删除全部学生信息请输入\"all\"，删除指定学号的学生信息请输入\"one\"\n");
		scanf("%s",delinfo);
		if(strcmp(delinfo,"all")==0)
		{
				int j;
				printf("您删除的学生信息如下：\n");
				printf("-----------学号------------姓名------------高数--------------英语--------------计算机\t\n");
				for(j=0;j<count;j++)
						printf("--------%d---------%s---------%d---------%d--------%d\t\n",student[j].number,student[j].name,student[j].gaoshu,student[j].yingyu,student[j].jisuanji);
				count=0;
				printf("删除成功\n\n");
		}
		else if(strcmp(delinfo,"one")==0)
		{
				struct student *p=NULL;
				int choice;

				int i,j,k=0;
				printf("请输入你要删除人的学号:");
				scanf("%d",&choice);
				for(i=0;i<count;i++)
				{
						if(choice==student[i].number)
						{
								k=1;j=i;break;
						}
				}
				if(k)
				{
						if(count==1)
						{
								p=&student[0];
								free(p);
								count=0;
						}
						else
						{

								for(i=j;i<count;i++)
								{
										                     student[i]=student[i+1];
								}
								count-=1;
						}
						printf("删除成功\n\n");
				}
				else
				{
						printf("输入数据错误！\n");
				}

		}
	     admin_menu();
}

//修改学生信息(老师）

void revise_student()
{
		int in;
		do
		{
				printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
				printf("-----      请选择想要执行修改的选项       -----\n");
				printf("-----       1.依据学好修改                -----\n");
				printf("-----       2.依据姓名修改                -----\n");
				printf("-----       3.不修改                      -----\n");
				printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
				printf("\n");
				printf("请输入您的选项(1~3):\n");
				scanf("%d",&in);
				fflush(stdin);
				if(in<1||in>3)
				{
						printf("对不起！没有此选项，请再次输入！\n");
						continue;
				}
				else
				{
						break;
				}
		}while(1);
		switch(in)
		{
				case 1:
						revise_student_number();
						break;
				case 2:
						revise_student_name();
						break;
				case 3:
						break;
		}
		student_menu();

}

//依据学号修改（老师）
void revise_student_number()
{
		int i=0,choice,flag,revise_number;
		do
		{
				printf("请输入需修改学生的学号：");
				scanf("%d",&revise_number);
				for(i=0;i<count;i++)
				{
						if(student[i].number==revise_number)
						{
								printf("可修改科目成绩如下所示：\n");
								printf("\n请输入您的选择(1~3):\n");
								printf("请输入您的选择：\n");
								printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
								printf("-----       1.高数        -----\n");
								printf("-----       2.英语        -----\n");
								printf("-----       3.计算机      -----\n");
								printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
								scanf("%d",&choice);
								switch(choice)
								{
										case 1:
												printf("输入修改的高数成绩:\n");
												scanf("%d",&student[i].gaoshu);
												break;

										case 2:
												printf("输入修改的英语成绩:\n");
												scanf("%d",&student[i].yingyu);
												break;

										case 3:
												printf("输入修改计算机成绩:\n");
												scanf("%d",&student[i].jisuanji);
												break;
								}

						}
						if(i==S)
						{
								printf("\n查无此学生！");
								getchar();
						}
				}


						printf("\n\n继续修改？(y/n)\n");
						choice=getchar();

						if(choice=='y'||choice=='Y')
						{
						     	flag=1;
								printf("继续此操作！\n");


						}
						else
						
						     	flag=0;

		}while(flag=1);
		printf("点击任意键回到主菜单:\n");
		getchar();
		student_menu();

}

//依据姓名修改（老师）
void revise_student_name()
{
		int i=0,choice,flag;
		char revise_name[32];
		do
		{
				printf("请输入需修改学生姓名：");
				scanf("%s",revise_name);
				for(i=0;i<count;i++)
				{
						if(strcmp(student[i].name,revise_name)==0)
						{
								printf("可修改科目成绩如下所示：\n");
								printf("\n请输入您的选择(1~4):\n");
								printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
								printf("-----       1.高数        -----\n");
								printf("-----       2.英语        -----\n");
								printf("-----       3.计算机      -----\n");
								printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
								scanf("%d",&choice);
								switch(choice)
								{
										case 1:
												printf("输入修改的高数成绩:\n");
												scanf("%d",&student[i].gaoshu);
												break;

										case 2:
												printf("输入修改的英语成绩:\n");
												scanf("%d",&student[i].yingyu);
												break;

										case 3:
												printf("输入修改计算机成绩:\n");
												scanf("%d",&student[i].jisuanji);
												break;
								}

						}
				}
						if(i==S)
						{
								printf("\n查无此学生！");
								getchar();
						}

						printf("\n\n继续修改？(y/n)");
						choice=getchar();

						if(choice=='y'||choice=='Y')
						{
								flag=1;
								printf("继续此操作！\n");

						}
						else
						{
								flag=0;
								break;
						}

				}while(flag=1);
				printf("点击任意键回到主菜单:\n");
				getchar();
				student_menu();
		}



		//查找学生信息（学号，姓名，班级）
		void search_student()
		{
				int xx;
				char choice,yy[20];
				int i,j,k=0;
				system("CLS");
				if(count==0)
				{
						printf("系统里面没有任何学生的信息！\n");
						stu_sign();
				}
				printf("三种查找方式：学号，姓名，班级\n");
				printf("如果按学号查找请输1，如果按姓名查找请输2，如果按班级查找请输3\n");
				printf("请输入您查找的方式：");
				scanf("%s",&choice);
				if(choice=='1')
				{

						printf("请输入需要查找学生的学号：");
						scanf("%d",&xx);
						printf("您所查找的学生的信息为：\n");
						printf("----学号----姓名----高数成绩----英语成绩----计算机成绩----\t\n");
						for(i=0;i<count;i++)
						{
								if(xx==student[i].number)
								{
										j=i;k=1;
										printf("-------%d---------%s---------%d---------%d--------%d------\t\n",student[j].number,student[j].name,student[j].gaoshu,student[j].yingyu,student[i].jisuanji);
								}
						}
						if(k==0)
								printf("输入信息有误：\n");
				}
				else if(choice=='2')
				{
						printf("请输入需要查找学生的姓名：\n");

						scanf("%s",yy);
						printf("您所查找的学生的信息为：\n");
						printf("----学号----姓名----高数成绩----英语成绩----计算机成绩----\t\n");
						for(i=0;i<count;i++)
						{
								if(strcmp(yy,student[i].name)==0)
								{
										j=i;k=1;
										printf("----%d-------%s-------%d-------%d-------%d----\t\n",student[j].number,student[j].name,student[j].gaoshu,student[j].yingyu,student[j].jisuanji);
								}

						}

						if(k==0)
								printf("输入信息有误：\n");
				}

				else if(choice=='3')

				{
						printf("请输入需要查找学生的班级：\n");
						scanf("%d",&xx);
						printf("您所查找的学生的信息为：\n");
						printf("----学号----姓名----高数----英语----计算机----\t\n");
						for(i=0;i<count;i++)
						{
								if(xx==student[i].grade)
								{
										j=i;k=1;
										printf("----%d-------%s-------%d-------%d-------%d----\t\n",student[j].number,student[j].name,student[j].gaoshu,student[j].yingyu,student[i].jisuanji);
								}

						}

						if(k==0)
								printf("输入信息有误：\n");
				}
				stu_sign();

		}
/*
//排序
void  sort()
{
		int in;
		do
		{
				
				printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
				printf("-----      请选择想要执行排序的选项       -----\n");
				printf("-----       1.依据总成绩                -----\n");
				printf("-----       2.依据学号                -----\n");
				printf("-----       3.不排序                     -----\n");
				printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
				printf("\n");
				printf("请输入您的选项(1~3):\n");
				scanf("%d",&in);
				fflush(stdin);
				if(in<1||in>3)
				{
						printf("对不起！没有此选项，请再次输入！\n");
						continue;
				}
				else
				{
						break;
				}
		}while(1);
		switch(in)
		{
				case 1:
						sort_sum();
						break;
				case 2:
						sort_number();
						break;
				case 3:
						break;
		}
}


*/

		//排序（按总成绩）
		void sort_sum()
		{
				struct student *p1[S],*(*p2),*temp;
				int i,j;
				system("cls");
				p2=p1;
				for( i=0;i<count;i++)
				{
						p1[i]=student+i;
				}
				for( i=0;i<count;i++)
				{
						for( j=i+1;j<count;j++)
						{
								if((*(p2+i))->sum<(*(p2+j))->sum)
								{
										temp=*(p2+i);
										*(p2+i)=*(p2+j);
										*(p2+j)=temp;
								}
						}
					    

				}

				printf("按照总成绩排序之后的信息为：\n");
				printf("----学号----姓名----总成绩----名次\t\n");
				for( i=0;i<count;i++)
				{
						student[i].sum=student[i].gaoshu+student[i].yingyu+student[i].jisuanji;
						printf("-----%d-------%s-------%d--------%d\n",(*(p2+i))->number,(*(p2+i))->name,(*(p2+i))->sum,i+1);
				}

				stu_sign();

		}

/*
//按学号排序
void  sort_number()
		{
				struct student *p1[S],*(*p2),*temp;
				int i,j;
				system("cls");
				p2=p1;
				for( i=0;i<count;i++)
				{
						p1[i]=student+i;
				}
				for( i=0;i<count;i++)
				{
						for( j=i+1;j<count;j++)
						{
								if((*(p2+i))->sum<(*(p2+j))->sum)
								{
										temp=*(p2+i);
										*(p2+i)=*(p2+j);
										*(p2+j)=temp;
								}
						}

				}

				printf("按照学号排序之后的信息为：\n");
				printf("----学号----姓名----高数----英语---计算机\t\n");
				for( i=0;i<count;i++)
				{
			student[i].gaoshu+student[i].yingyu+student[i].jisuanji;
						printf("----%d-----%s----%d-----%d-----%d\n",(*(p2+i))->number,(*(p2+i))->name,(*(p2+i))->gaoshu,(*p2[i]).yingyu,(*p2[i]).jisuanji);
				}

				sign();

		}


*/


		//储存信息
		void save()
		{
				int i;
				FILE *fp=NULL;
				if((fp=fopen("student.txt","w"))==NULL)
				{

						printf("打开文件失败！");
						exit(0);
				}

				for(i=0;i<count;i++)
				{
						fwrite(&student[i], sizeof(student[i]), 1, fp);
				}
				if(ferror(fp))
				{
						fclose(fp);
						perror("写文件失败！\n");
						return;
				}
				printf("存储文件成功！\n");
				fclose(fp);
				stu_sign();
		}


		//导出信息
		void read()
		{

				struct student t;
				int i=0;
				FILE* fp = fopen("student.txt", "r");
				count=0;
				if(NULL==fp)
				{
						perror("读取文件打开失败！\n");
						return;
				}
				memset(student,0x0,sizeof(student));
				while(1)
				{
						fread(&t,sizeof(t),1,fp);
						if(ferror(fp))
						{
								fclose(fp);
								perror("读文件过程失败！\n");
								return;
						}
						if(feof(fp))
						{

								break;
						}
						student[i]=t;
						i++;
				}
				fclose(fp);
				count=i;
				printf("导出文件成功！\n");
				stu_sign();
		}


		//主菜单
		void student_menu()
		{
				int n=0;

				system("CLS");	
				printf(" 学生信息管理系统\ni");
				printf("\n");
				printf("-------------------MENU-----------------\n");
				printf(" 1.登记学生信息\n");
				printf(" 2.删除学生信息\n");
				printf(" 3.修改学生信息\n");
				printf(" 4.显示已经登记的学生\n");
				printf(" 5.查找\n");
		//		printf(" 5.1按学号查找\n");
		//		printf(" 5.2按姓名查找\n");
		//		printf(" 5.3按班级查找\n");
				printf(" 6依据总成绩排序\n");
				printf(" 7.存储到文件\n");
				printf(" 8.从文件导出\n");
				printf(" 9.退出系统\n");
				printf(" 请选择：");
				scanf("%d",&n);
				switch (n)
				{
						case 1:
								add_student();
								break;
						case 2:
								del_student();
								break;
						case 3:
								revise_student();
								break;
						case 4:
							displaystudentbasic();
								break;
						case 5:

								search_student();
								break;
						case 6:
								sort_sum();
								break;
						case 7:
								save();
								break;
						case 8:
								read();
								break;
						case 9:
								exit(0);
								break;
						default:
								{
										printf("请输入1-9之间的数字，谢谢！\n");
										break;
								}

				}
		         
				student_menu();

		}

