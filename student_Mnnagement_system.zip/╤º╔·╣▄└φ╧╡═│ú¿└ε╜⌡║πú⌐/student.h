#ifndef _STUDENT_H
#define _STUDENT_H
#include<stdio.h>
typedef struct student
{
		int number;
                int rank;
		int age;
		char name[32];
		char sex[2];
		int grade;
		int gaoshu;
		int yingyu;
		int jisuanji;
		int sum;
		double average;
}STUDENT;




void stu_sign();
void passwd_student();
void add_student();
void sort_sum();
void del_student();
void revise_student();
void revise_student_number();
void revise_student_name();
void search_student();
void displaystudentbasic();
void save();
void read();
void student_menu();

#endif
