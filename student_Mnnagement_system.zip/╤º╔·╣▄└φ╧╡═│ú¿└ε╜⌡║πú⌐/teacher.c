#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include"student.h"
#include"teacher.h"
#include "main.h"
#define T 20

TEACHER teacher[T];
void teacher_menu();

//密码输入

void passwd_teacher()
{
		char id[32]="MDA14130",passwd[32]="12345678";
		int i,n=3;
		printf("***********欢迎登录高校信息管理系统!**********\n");
		while(1)
		{
		printf("请输入登录帐号与密码：");
		     scanf("%s%s",id,passwd);
		if(strcmp(id,"MDA14130")==0&&strcmp(passwd,"12345678")==0)
		{
				printf("\t帐号密码正确！欢迎登录！\n");
				printf("******      欢迎进入主菜单      ******\n");
				teacher_menu();

		}
		else
		{
				
				printf("对不起!帐号或者密码错误，请确认后再次登录！");
				printf("您还剩%d次登录机会！",n);
				n--;
				if(n==0)
				{
						printf("您已超过当日登录次数，请隔日再试!");
						break;

				}

		}
		}
		tea_sign();


}





//提示
void tea_sign()
{
		char biaozhi[32];
		printf("\n");
		printf("------------是否进入主菜单输入：yes/no\n");
		scanf("%s",biaozhi);
		if(strcmp(biaozhi,"yes")==0)
		{
				teacher_menu();
		}
		else if(strcmp(biaozhi,"no")==0)
				exit(0);
		else
		{
				printf("请输入正确的字符，谢谢！\n");
				tea_sign();
		}
}


//添加信息
void add1()
{
		int in;
		printf("------------请选择您需要添加信息对像------------\n");
		do
		{
				printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
				printf("---           1.添加学生            ---\n");
				printf("---           2.添加老师            ---\n");
				printf("---           3.不执行添加          ---\n");
				printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
				printf("\n");
				printf("输入您的选择（1～3）：");
				scanf("%d",&in);
				fflush(stdin);
				if(in<1||in>3)
				{
						printf("对不起！超过范围，请从新选择！");
						continue;
				}
				else
				{
						break;
				}


		}while(1);
		switch(in)
		{
				case 1:
						add_student();
						break;
				case 2:
						add_teacher();
						break;
				case 3:
						break;
		}

}

//添加老师基本信息
void add_teacher()
{
		int rs; 
		int i,k=1;

		system("CLS");

		printf("请输入需要输入几个老师信息：");
		scanf("%d",&rs);
		for(i=count;i<count+rs;i++,k++)
		{
				printf("请输入第%d个老师的编号：",k);
				scanf("%d",&teacher[i].number);
				printf("请输入老师的姓名：");
				scanf("%s",teacher[i].name);
				printf("请输入老师的年龄：");
				scanf("%d",&teacher[i].age);
				printf("请输入老师的性别：");
				scanf("%s",teacher[i].sex);
				printf("请输入老师的电话：");
				scanf("%s",teacher[i].phone);
		}

		count=count+rs;
		count++;

		tea_sign();
}


//删除信息 
void del1()
{
		int in;
		do
		{
				printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
				printf("---           1.删除学生            ---\n");
				printf("---           2.删除老师            ---\n");
				printf("---           3.不执行删除          ---\n");
				printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
				printf("\n");
				printf("输入您的选择（1～3）：");
				scanf("%d",&in);
				fflush(stdin);
				if(in<1||in>3)
				{
						printf("对不起！超过范围，请从新选择！");
						continue;
				}
				else
				{
						break;
				}


		}while(1);
		switch(in)
		{
				case 1:
						del_student();
						break;
				case 2:
						del_teacher();
						break;
				case 3:
						break;
		}



}


//删除老师信息


void del_teacher()
{
		char delinfo[32];

		system("CLS");
		printf("删除全部老师信息请输入\"all\"，删除指定编号的老师信息请输入\"one\"\n");
		scanf("%s",delinfo);
		if(strcmp(delinfo,"all")==0)
		{
				int j;
				printf("您删除的老师信息如下：\n");
				printf("-----------编号-------------姓名-------------年龄--------------电话--------------地址\t\n");
				for(j=0;j<count;j++)
						printf("----%d-------%s-------%d-------%s-------%s\t\n",teacher[j].number,teacher[j].name,teacher[j].age,teacher[j].phone,teacher[j].address);
				count=0;
				printf("删除成功\n\n");
		}
		else if(strcmp(delinfo,"one")==0)
		{
				struct teacher *p=NULL;
				int choice;

				int i,j,k=0;
				printf("请输入你要删除人的编号:");
				scanf("%d",&choice);
				for(i=0;i<count;i++)
				{

						if(choice==teacher[i].number)
						{
								k=1;j=i;break;
						}
				}
				if(k)
				{ 
						if(count==1)
						{
								p=&teacher[0];
								free(p);
								count=0;
						}
						else
						{

								for(i=j;i<count;i++)
								{
										teacher[i]=teacher[i+1];
								}
								count-=1;
						}
						printf("删除成功\n\n");
				}
				else
				{
						printf("输入数据错误！\n");
				}
		}
		tea_sign();
}

//修改信息

void revise1()
{
		int in; 
		do
		{
				printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
				printf("-----      请选择想要执行修改的选项       -----\n");
				printf("-----       1.修改学生信息                -----\n");
				printf("-----       2.修改老师信息                -----\n");
				printf("-----       3.不修改                      -----\n");
				printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
				printf("\n");
				printf("请输入您的选项(1~3):\n");
				scanf("%d",&in);
				fflush(stdin);
				if(in<1||in>3)
				{
						printf("对不起！没有此选项，请再次输入！\n");
						continue;
				}
				else
				{
						break;
				}
		}while(1);
		switch(in)
		{
				case 1:  
						revise_student();
						break;

				case 2:
						revise_teacher();
						break;
				case 3:
						break;
		}
}


//修改老师信息

void revise_teacher()
{
		int in; 
		do
		{
				printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
				printf("-----      请选择想要执行修改的选项       -----\n");
				printf("-----       1.依据学编号修改              -----\n");
				printf("-----       2.依据姓名修改                -----\n");
				printf("-----       3.不修改                      -----\n");
				printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
				printf("\n");
				printf("请输入您的选项(1~3):\n");
				scanf("%d",&in);
				fflush(stdin);
				if(in<1||in>3)
				{
						printf("对不起！没有此选项，请再次输入！\n");
						continue;
				}
				else
				{
						break;
				}
		}while(1);
		switch(in)
		{
				case 1:  
						revise_teacher_number();
						break;

				case 2:
						revise_teacher_name();
						break;
				case 3:
						break;
		}
}



//依据编号修改（老师）
void revise_teacher_number()
{
		int i=0,choice,flag,revise_teacher_number;
		do
		{
				printf("请输入需修改老师的编号：");
				scanf("%d",&revise_teacher_number);
				for(i=0;i<count;i++)
				{
						if(teacher[i].number==revise_teacher_number)
						{
								printf("可修改科目成绩如下所示：\n");
								printf("\n请输入您的选择(1~3):\n");
								printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
								printf("-----         1.电话        -----\n");
								printf("-----         2.住址        -----\n");
								printf("-----         3.编号        -----\n");
								printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
								scanf("%d",&choice);
								switch(choice)
								{
										case 1:
												printf("输入修改的电话号码:\n");
												scanf("%s",teacher[i].phone);
												break;

										case 2:
												printf("输入修改的住址:\n");
												scanf("%s",teacher[i].address);
												break;
										case 3:
												printf("输入修改的编号:\n");
												scanf("%d",&teacher[i].number);
												break;
								}

						}
						if(i==T)
						{
								printf("\n查无此老师！");
								getchar();
						}

						printf("\n\n继续修改？(y/n)");
						choice=getchar();

						if(choice=='y'||choice=='Y')
						{
								flag=1;
								printf("继续此操作！\n");

						}
						else
						{
								flag=0;
								break;
						}
				}

		}while(flag=1);
		printf("点击任意键回到主菜单:\n");
		getchar();
		teacher_menu();


}



//依据姓名修改（老师）
void revise_teacher_name()
{
		int i=0,choice,flag;
		char revise_teacher_name[32];
		do
		{
				printf("请输入需修改老师姓名：");
				scanf("%s",revise_teacher_name);
				for(i=0;i<count;i++)
				{
						if(strcmp(teacher[i].name,revise_teacher_name)==0)
						{
								printf("可修改科目成绩如下所示：\n");
								printf("\n请输入您的选择(1~3):\n");
								printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
								printf("-----           1.电话           -----\n");
								printf("-----           2.住址           -----\n");
								printf("-----           3.编号           -----\n");
								printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
								scanf("%d",&choice);
								switch(choice)
								{
										case 1:
												printf("输入修改的电话:\n");
												scanf("%s",teacher[i].phone);
												break;

										case 2:
												printf("输入修改的住址:\n");
												scanf("%s",teacher[i].address);
												break;

										case 3:
												printf("输入修改的编号:\n");
												scanf("%d",&teacher[i].number);
												break;
								}
						}
						if(i==T)
						{
								printf("\n查无此老师！");
								getchar();
						}

						printf("\n\n继续修改？(y/n)");
						choice=getchar();

						if(choice=='y'||choice=='Y')
						{
								flag=1;
								printf("继续此操作！\n");

						}
						else
						{
								flag=0;
								break;
						}

				}
		}while(flag=1);
		printf("点击任意键回到主菜单:\n");
		getchar();
		teacher_menu();
}





//查找
void search1()
{
		int in; 
		do
		{
				printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
				printf("-----        请选择想要执行选项            -----\n");
				printf("-----           1.查找学生                 -----\n");
				printf("-----           2.查找老师                 -----\n");
				printf("-----           3.不查找                   -----\n");
				printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
				printf("\n");
				printf("请输入您的选项(1~3):\n");
				scanf("%d",&in);
				fflush(stdin);//
				if(in<1||in>3)
				{
						printf("对不起！没有此选项，请再次输入！\n");
						continue;
				}
				else
				{
						break;
				}
		}while(1);
		switch(in)
		{
				case 1:  
						search_student();
						break;

				case 2:
						search_teacher();
						break;
				case 3:
						break;
		}
}



//查找老师信息（编号，姓名）
void search_teacher()
{
		int xx;
		char choice,yy[32];
		int i,j,k=0;
		system("clear");
		if(count==0)
		{
				printf("系统里面没有任何学生的信息！\n");
				tea_sign();
		}
		printf("两种查找方式：编号，姓名\n");
		printf("如果按编号查找请输1，如果按姓名查找请输2\n");
		printf("请输入您查找的方式：");
		scanf("%s",&choice);
		if(choice=='1')
		{

				printf("请输入需要查找老师编号：");
				scanf("%d",&xx);
				printf("您所查找的老师的信息为：\n");
				printf("----编号----姓名----年龄----电话----地址----\t\n");
				for(i=0;i<count;i++)
				{
						if(xx==teacher[i].number)
						{
								j=i;k=1;
								printf("----%d-------%s-------%d-------%s-------%s----\t\n",teacher[j].number,teacher[j].name,teacher[j].age,teacher[j].phone,teacher[j].address);
						}
				}
				if(k==0)

						printf("输入信息有误：\n");

		}
		else if(choice=='2')
		{
				printf("请输入需要查找老师的姓名：\n");

				scanf("%s",yy);
				printf("您所查找的老师的信息为：\n");
				printf("----编号----姓名----年龄----电话----地址----\t\n");
				for(i=0;i<count;i++)
				{
						if(strcmp(yy,teacher[i].name)==0)
						{
								j=i;k=1;
								printf("----%d-------%s-------%d-------%s-------%s----\t\n",teacher[j].number,teacher[j].name,teacher[j].age,teacher[j].phone,teacher[j].address);
						}

				}

				if(k==0)
						printf("输入信息有误：\n");
		}

		tea_sign();

}

void display1()
   {
   int in; 
   do
   {
   printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
   printf("-----        请选择想要执行选项            -----\n");
   printf("-----        1.显示学生                    -----\n");
   printf("-----        2.显示老师                    -----\n");
   printf("-----        3.不显示                      -----\n");
   printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
   printf("\n");
   printf("请输入您的选项(1~3):\n");
   scanf("%d",&in);
   fflush(stdin);
   if(in<1||in>3)
   {
   printf("对不起！没有此选项，请再次输入！\n");
   continue;
   }
   else
   {
   break;
   }
   }while(1);
   switch(in)
   {
   case 1:  
   displaystudentbasic();
   break;

   case 2:
   displayteacherbasic();
   break;
   case 3:
   break;
   }
   }


 


//老师信息
void displayteacherbasic()
{
		int i;
		system("CLS");
		if(count==0)
		{
				printf("not input before\n");
				getchar();
				return;
		}
		printf("老师信息如下所示：\n");
		printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
		printf("编号：\t姓名：\t年龄：\t电话：\n");
		for(i=0;i<count;i++)
		{
				printf("%d\t",teacher[i].number);
				printf("%s\t",teacher[i].name);
				printf("%d\t",teacher[i].age);
				printf("%s\t",teacher[i].phone);
		//		printf("%s\t",teacher[i].address);
				printf("\n");
		}

		printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
		printf("点击任意建继续！");
		getchar();



		tea_sign();
}




//主菜单
void teacher_menu()
{
		int n;

		system("CLS");
		printf("**********高校老师信息管理系统**********");
		printf("\n");
		printf("****************************************\n");
		printf("-------------------MENU-----------------\n");
		printf("-              1.添加信息              -\n");
		printf("-              2.删除学生              -\n");
		printf("-              3.修改信息              -\n");
		printf("-              4.显示基本信息          -\n");
		printf("-              5.查找信息              -\n");
		printf("-              6.退出系统              -\n");
		printf("----------------------------------------\n");
		printf("****************************************\n");
		printf(" 请选择(1~6)：");
		scanf("%d",&n);
		switch (n) 
		{
				case 1:
						add1();
						break;
				case 2:
						del1();
						break;
				case 3:
						revise1();
						break;
				case 4:
						display1();
						break;
				case 5:
						search1();
						break;

				case 6:
						exit(0);
						break;

				default:
						
						printf("请输入1~6之间的数字，谢谢！\n");
						teacher_menu();

						

		}

}


