#ifndef _TEACHER_H
#define _TEACHER_H
#include<stdio.h>
typedef struct teacher
{
		int number;
		int age;
		char name[32];
		char sex[2];
		char phone[32];
		char address[32];

}TEACHER;



void passwd_teacher();
void tea_sign();
void add1();
void add_teacher();
void del1();
void del_teacher();
void revise1();
void revise_teacher();
void revise_teacher_number();
void revise_teacher_name();
void search1();
void search_teacher();
void teacher_menu();
void display1();
void displayteacherbasic();



#endif
