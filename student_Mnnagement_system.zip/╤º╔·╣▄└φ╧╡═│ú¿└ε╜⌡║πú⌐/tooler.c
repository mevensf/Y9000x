#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include"student.h"
#include"teacher.h"
//#include "main.h"
#include "tooler.h"
#define  A  2



ADMIN  admin[A];
extern int count;
void admin_menu();
void admin_sign();
void display();
void displayadminbasic();
void add();
void add_admin();
void revise_admin();
void revise();
void search();


//提示
void admin_sign()
{
		char s[32];
		printf("\n");
		printf("还需要操作么？如果需要操作请输入：yes，否则请输入：no\n");
		scanf("%s",s);
		if(strcmp(s,"yes")==0)
		{
				admin_menu();
		}
		else if(strcmp(s,"no")==0)
				exit(0);
		else
		{
				printf("请输入正确的字符，谢谢！\n");
				admin_sign();
		}
}



//主菜单
void admin_menu()
{
		int n;

		system("CLS");
		printf("****************欢迎光临******************\n");  
		printf("*************高校信息管理系统*************\n");
		printf("-------------------MENU------------------\n");
		printf("-               1.添加信息              -\n");
		printf("-               2.删除信息              -\n");
		printf("-               3.修改信息              -\n");
		printf("-               4.显示信息              -\n");
		printf("-               5.查找信息              -\n");
		printf("-               6.保存信息              -\n");
		printf("-               7.退出系统              -\n");
		printf("-----------------------------------------\n");
		printf(" 请选择(1~7)：");
		scanf("%d",&n);
		switch (n)
		{
				case 1:
						add();
						break;
				case 2:
						del();
						break;
				case 3:
						revise();
						break;
				case 4:
						display();
						break;
				case 5:
						search();
						break;

				case 6:
						save();
						break;
				case 7:
						exit(0);
						break;
				default:
						{
								printf("请输入1~7之间正确数字，谢谢！\n");
								admin_menu();
						}

		}

}



void passwd_admin()
{
		char id[32]="MDA14130",passwd[32]="12345678";
		int i,n=3;
		printf("***********欢迎登录高校信息管理系统!**********\n");
		while(1)
		{
				printf("请输入登录帐号与密码：");
				scanf("%s%s",id,passwd);
				if(strcmp(id,"MDA14130")==0&&strcmp(passwd,"12345678")==0)
				{
						printf("\t帐号密码正确！欢迎登录！\n");
						printf("******      欢迎进入主菜单      ******\n");
						admin_menu();

				}
				else
				{
						
						printf("对不起!帐号或者密码错误，请确认后再次登录！");
						printf("您还剩%d次登录机会！",--n);

						if(n==0)
						{
								printf("您已超过当日登录次数，请隔日再试!");
								break;
						}
						//         passwd_admin();

				}
		}
		//      admin_sign();


}




//添加信息
void add()
{
		int in;
		printf("*****请选择以下您想要添加信息的对象：*****\n");
		printf("-----------------------------------------\n");
		printf("-------      1.添加学生信息        ------\n");
		printf("-------      2.添加老师信息        ------\n");
		printf("-------      3.添加个人信息        ------\n");
		printf("-------      4.不执行              ------\n");
		printf("-----------------------------------------\n");
		printf("请选择（1~4）:");
		scanf("%d",&in);
		if(in<1||in>4)
		{
				printf("输入错误！请重新确认您的选择！\n");
				add();
		}
		switch(in)
		{
				case 1:
						add_student();
						break;
				case 2:
						add_teacher();
						break;

				case 3:
						add_admin();
						break;
				case 4:

						break;

		}
		admin_sign();

}


//添加个人基本信息
void add_admin()
{
		int i;
		char a[32];
		system("clear");
		printf("请完成以下管理员基本信息的添加：\n");
		printf("请输入个人姓名：\n");
		scanf("%s",admin[i].name);
		printf("请输入个人年龄：\n");
		scanf("%d",&admin[i].age);
		printf("请输入个人性别：\n");
		scanf("%s",admin[i].sex);
		printf("请输入个人联系电话：\n");
		scanf("%s",admin[i].phone);




}



//显示信息（学生，老师，管理员）
void display()
{
		int in;
		printf("--------------------------------------------------\n");
		printf("***********请选择您想要显示的人员信息*************\n");
		printf("*              1.学生信息                        *\n");
		printf("*              2.老师信息                        *\n");
		printf("*              3.管理员信息                      *\n");
		printf("*              4.不执行    		         *\n");
		printf("**************************************************\n");
		printf("--------------------------------------------------\n");
		printf("\n");
		printf("请输入（1~4）:");
		scanf("%d",&in);
		if(in<1||in>4)
		{
				printf("data error！请输入正确选项！");
				display();


		}
		switch(in)
		{
				case 1:
						displaystudentbasic();
						break;
				case 2:
						displayteacherbasic();
						break;
				case 3:

						displayadminbasic();
						break;
				case 4:

						break;

		}




}

//管理员信息
void displayadminbasic()
{
		int i;
		system("CLS");
		if(count==0)
		{
				printf("not input before\n");
				getchar();
				return;
		}
		printf("管理员信息如下所示：\n");
		printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
		printf("编号：\t姓名：\t年龄：\t电话：\t地址：\n");
		for(i=0;i<count;i++)
		{
				printf("%d\t",admin[i].number);
				printf("%s\t",admin[i].name);
				printf("%d\t",admin[i].age);
				printf("%s\t",admin[i].phone);
				printf("%s\t",admin[i].address);
		}
		printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
		printf("点击任意建继续！");
		getchar();

		// admin_sign();
}

//删除
void del()
{
        int in;
        do
        {
                printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
                printf("---           1.删除学生            ---\n");
                printf("---           2.删除老师            ---\n");
                printf("---           3.删除管理员          ---\n");
                printf("---           4.不执行删除          ---\n");
                printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
                printf("\n");
                printf("输入您的选择（1～4）：");
                scanf("%d",&in);
                fflush(stdin);
                if(in<1||in>4)
                {
                        printf("对不起！超过范围，请从新选择！");
                        continue;
                }
                else
                {
                        break;
                }


        }while(1);
        switch(in)
        {
                case 1:
                        del_student();
                        break;
                case 2:
                        del_teacher();
                        break;
                case 3:
			del_admin();
                        break;
		case 4:
			break;
        }


}


//删除管理员信息


void del_admin()
{
		char delinfo[32];

		system("CLS");
		printf("删除个人全部信息请输入\"all\"，删除部分信息请输入\"one\"\n");
		scanf("%s",delinfo);
		if(strcmp(delinfo,"all")==0)
		{
				int j;
				printf("您删除的个人信息如下：\n");
				printf("-----------编号-------------姓名-------------年龄--------------电话--------------地址\t\n");
				for(j=0;j<count;j++)
						printf("----%d-------%s-------%d-------%s-------%s\t\n",admin[j].number,admin[j].name,admin[j].age,admin[j].phone,admin[j].address);
				count=0;
				printf("删除成功\n\n");
		}
		else if(strcmp(delinfo,"one")==0)
		{
				struct admin *p=NULL;
				int choice,i,j,k=0;
				for(i=0;i<count;i++)
				{
						if(choice=admin[i].number)
						{
								k=1;j=i;break;

						}
				}
				if(k)
				{
						if(count==1)
						{
								p=&admin[0];
								free(p);
								count=0;
						}
						else
						{

								for(i=j;i<count;i++)
								{
										admin[i]=admin[i+1];
								}
								count-=1;
						}
						printf("删除成功\n\n");
				}
				else
				{
						printf("输入数据错误！\n");
				}

		}
		admin_sign();
}





//修改信息

void revise()
{
		int in; 
		do
		{
				printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
				printf("-----      请选择想要执行修改的选项       -----\n");
				printf("-----       1.修改学生信息                -----\n");
				printf("-----       2.修改老师信息                -----\n");
				printf("-----       3.修改管理员信息              -----\n");
				printf("-----       4.不修改                      -----\n");
				printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
				printf("\n");
				printf("请输入您的选项(1~4):\n");
				scanf("%d",&in);
				fflush(stdin);
				if(in<1||in>4)
				{
						printf("对不起！没有此选项，请再次输入！\n");
						continue;
				}
				else
				{   
						break;
				}   
		}while(1);
		switch(in)
		{
				case 1:
						revise_student();
						break;
				case 2:
						revise_teacher();
						break;
				case 3:
						revise_admin();
						break;
				case 4:
						break;
		}
		admin_sign();

}


//修改管理员
void revise_admin()
{
		int i=0,choice;

		printf("可修改选项如下所示：\n");
		printf("\n请输入您的选择(1~5):\n");
		printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
		printf("---                1.姓名                ---\n");
		printf("---                2.年龄                ---\n");
		printf("---                3.编号                ---\n");
		printf("---                4.电话                ---\n");
		printf("---                5.地址                ---\n");
		printf("---                6.不修改              ---\n");
		printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
		scanf("%d",&choice);
		switch(choice)
		{
				case 1:
						printf("输入修改的姓名:\n");
						scanf("%s",admin[i].name);
						break;

				case 2:
						printf("输入修改的年龄:\n");
						scanf("%d",&admin[i].age);
						break;

				case 3:
						printf("输入修改的编号:\n");
						scanf("%d",&admin[i].number);
						break;
				case 4:
						printf("输入修改的电话:\n");
						scanf("%s",admin[i].phone);
						break;
				case 5:
						printf("输入修改的地址:\n");
						scanf("%s",admin[i].address);
						break;
				case 6:

						printf("不修改\n");
						break;
		}


		printf("点击任意键回到主菜单:\n");
		getchar();

}


//查找信息

void search()
{
		int in; 
		do
		{
				printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
				printf("-----      请选择想要查找选项             -----\n");
				printf("-----       1.查找学生信息                -----\n");
				printf("-----       2.查找老师信息                -----\n");
				printf("-----       3.查找管理员信息              -----\n");
				printf("-----       4.不查找                      -----\n");
				printf("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~\n");
				printf("\n");
				printf("请输入您的选项(1~4):\n");
				scanf("%d",&in);
				fflush(stdin);
				if(in<1||in>4)
				{
						printf("对不起！没有此选项，请再次输入！\n");
						continue;
				}
				else
				{   
						break;
				}   
		}while(1);
		switch(in)
		{
				case 1:
						search_student();
						break;
				case 2:
						search_teacher();
						break;
				case 3:
						search_admin();
						break;
				case 4:
						break;
		}
		

}

//查找管理员信息

void search_admin()
{
        int xx;
        char choice,yy[32];
        int i,j,k=0;
        system("clear");
        if(count==0)
        {
                printf("系统里面没有任何管理员的信息！\n");
                admin_sign();
        }
        printf("两种查找方式：编号，姓名\n");
        printf("如果按编号查找请输1，如果按姓名查找请输2\n");
        printf("请输入您查找的方式：");
        scanf("%s",&choice);
        if(choice=='1')
        {

                printf("请输入需要查找管理员编号：");
                scanf("%d",&xx);
                printf("您所查找管理员的信息为：\n");
                printf("----编号----姓名----年龄----电话----地址----\t\n");
                for(i=0;i<count;i++)
                {
                        if(xx==admin[i].number)
                        {
                                j=i;k=1;
                                printf("-------%d--------%s--------%d-------%s-------%s------\t\n",admin[j].number,admin[j].name,admin[j].age,admin[j].phone,admin[j].address);
                        }
                }
                if(k==0)

                        printf("输入信息有误：\n");

        }
        else if(choice=='2')
        {
                printf("请输入需要查找管理员的姓名：\n");
                for(i=0;i<count;i++)
                {
                        if(strcmp(yy,admin[i].name)==0)
                        {
                                j=i;k=1;
                                printf("------%d--------%s--------%d--------%s--------%s------\t\n",admin[j].number,admin[j].name,admin[j].age,admin[j].phone,admin[j].address);
                        }

                }

                if(k==0)
                        printf("输入信息有误：\n");
        }

        admin_sign();

}





