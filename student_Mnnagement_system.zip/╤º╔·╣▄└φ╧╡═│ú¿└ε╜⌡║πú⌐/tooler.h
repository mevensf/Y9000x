#ifndef _TOOLER_H
#define _TOOLER_H
#include<stdio.h>
typedef struct admin
{
		int number;
		int age;
		char name[32];
		char sex[2];
		char phone[32];
		char address[32];  
}ADMIN;



void admin_sign();
void passwd_admin();
void add();
void add_admin();
void del();
void del_admin();
void revise();
void display();
void displaybasic();
void search();
void search_admin();
void admin_menu();


#endif
